Name: Kavin Jeyasankar

2. The biggest challenge I encountered was choosing which data structure to use to split up the dictionary into
separate families. I also had some trouble changing the display word to reflect what was shown in each family.

3. I liked the concept behind the project, a hangman that people cannot win with a reasonable amount of guesses
was a good idea. But the vagueness of what data structure we could use made it pretty difficult.

4. I spent about 19 hours working on this project.

5. N/A